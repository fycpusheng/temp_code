﻿
#include <iostream>
#include <sstream>

template<typename T>
std::string t_to_string(T n)
{
	std::ostringstream stream;
	stream<<n;  //n为int类型
	
	return stream.str();
}